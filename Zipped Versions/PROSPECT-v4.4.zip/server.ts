import 'dotenv/config';
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from '@google/genai';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON body parser
  app.use(express.json());

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.post("/api/analyze-cohort", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(400).json({ error: "Gemini API key is not configured in the server environment (.env)" });
      }

      const { cohortKey, metrics, history, futureMonths, availableTiers } = req.body;

      const ai = new GoogleGenAI({ apiKey });

      const prompt = `You are a professional telecom/subscription business analyst. Analyze this cohort performance and suggest recommendations.
Cohort Key: ${JSON.stringify(cohortKey)}
Metrics (MAPE & Score): ${JSON.stringify(metrics)}
Historical Actuals vs Forecast: ${JSON.stringify(history)}
Available Product L2 (tariff) Tiers: ${JSON.stringify(availableTiers)}
Future Forecast Months: ${JSON.stringify(futureMonths)}

Provide your response in JSON format matching this exact schema:
{
  "varianceExplanation": "A detailed analysis (in markdown) explaining why actuals deviated from the forecast...",
  "visualStorySummary": "A short description of the cohort's visual story",
  "recommendations": [
    {
      "id": "string (unique code)",
      "name": "string (name of action)",
      "rationale": "string (business case rationale)",
      "capability": "volume" | "tariff_mix" | "revenue",
      "type": "market_event" | "yield_event" | "pricing_event",
      "futureEvents": [
        // Array of event objects corresponding to the type:
        // For market_event: { scenario: 'Inflow'|'Outflow'|'Retention'|'ARPU', segment: string, product: string, productL2?: string, channel: string, channelL2?: string, date: string (yyyy-MM), subscriberVolume: number, customerVolume: number, revenue: number, arpu: number, contractLength: number, comment: string }
        // For yield_event: { ibro: 'Inflow'|'Retention', segment: string, product: string, channelL1: string, channelL2: string, month: string (yyyy-MM), tariffMix: Record<tierName, pct (number between 0 and 100)>, rollForward: boolean, name?: string, comment?: string }
        // For pricing_event: { segment: string, product: string, productL2: string, channelL1: string, channelL2: string, month: string (yyyy-MM), inputMode: 'percentage'|'absolute', amount: number, target: 'cohorts'|'cohorts+base'|'base-only', cohortScope: 'inflow'|'retention'|'both', duration: 'one-off'|'recurring', name?: string, comment?: string }
      ],
      "historicalEvents": [
        // Mirroring futureEvents but mapped to corresponding months in the historical window (from the history array months, e.g. mapping 2025-03 to 2024-03).
      ]
    }
  ]
}

Guidelines for impact values:
- For market_event Outflow: positive subscriberVolume will DECREASE outflow (representing retention/churn reduction). Negative subscriberVolume will INCREASE outflow (representing churn increase). Be mathematically consistent: to reduce outflow/churn, suggest a positive volume.
- For market_event Inflow: positive subscriberVolume increases inflow.
- For yield_event tariffMix: the values in tariffMix must sum to 100. Key names must match the tier names in the available product L2 tiers.
- For pricing_event: amount represents percentage (e.g. 5 for +5%) or absolute (e.g. 2.50 for +2.50 euros).
- Provide a mix of 3-4 recommendations across Volume, Tariff Mix, and Revenue. Ensure they are creative, highly detailed, and tailored to the segment, product, and channel.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        }
      });

      const responseText = response.text || '';
      res.json(JSON.parse(responseText));
    } catch (error: any) {
      console.error("AI Cohort Audit error:", error);
      res.status(500).json({ error: error.message || "Failed to analyze cohort" });
    }
  });


  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve static files from dist
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
